
export const OPENSEA_SLUG = "lofipepe";

export const REDIS_CHANNEL = "pepe-sales";

export const PEPE_NFT = "0x0fcbd68251819928c8f6d182fc04be733fa94170";
